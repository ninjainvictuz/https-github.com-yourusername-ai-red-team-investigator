import React, { useState, useEffect } from "react";

interface ThreatBreakdown {
  credential_risk: number;
  infrastructure_risk: number;
  application_risk: number;
  brand_risk: number;
}

interface RiskFactor {
  type: string;
  text: string;
}

interface RecommendationAction {
  priority: string;
  action: string;
}

interface EvidenceCard {
  id?: string;
  source_title?: string;
  signal_type?: string; // NEW SIGNAL CLASSIFICATION VALUE
  finding: string;
  risk_impact?: string;
  confidence?: number;
  url?: string;
}

interface AttackPhase {
  step: number;
  phase: string;
  description: string;
}

interface ThreatIntelPayload {
  headline: string;
  executive_brief: string;
  primary_threat?: string;
  recommendations?: RecommendationAction[];
  risk_analysis: {
    score: number;
    breakdown: ThreatBreakdown;
    factors: RiskFactor[];
  };
  evidence_cards: EvidenceCard[];
  attack_narrative: AttackPhase[];
  sources_audited: string[];
}

export default function App() {
  const [domain, setDomain] = useState<string>("");
  const [loading, setLoading] = useState<boolean>(false);
  const [intelData, setIntelData] = useState<ThreatIntelPayload | null>(null);
  const [feedLogs, setFeedLogs] = useState<string[]>([]);
  const [isMonitored, setIsMonitored] = useState<boolean>(false);

  useEffect(() => {
    if (domain.trim()) {
      const cleanKey = domain.replace(/^(^\w+:|^)\/\//, "").trim().toLowerCase();
      setIsMonitored(localStorage.getItem(`monitor-${cleanKey}`) === "enabled");
    } else {
      setIsMonitored(false);
    }
  }, [domain]);

  function toggleContinuousMonitoring() {
    if (!domain.trim()) return;
    const cleanKey = domain.replace(/^(^\w+:|^)\/\//, "").trim().toLowerCase();
    
    localStorage.setItem(`monitor-${cleanKey}`, "enabled");
    setIsMonitored(true);
    alert(`[✓] Enterprise Security Sync: Continuous monitoring successfully enabled for ${cleanKey}.`);
  }

  async function generateThreatBrief() {
    if (!domain.trim() || loading) return;

    const localizedDomain = domain.replace(/^(^\w+:|^)\/\//, "").trim().toLowerCase();

    setLoading(true);
    setIntelData(null);
    setFeedLogs([
      `[+] Opening connection parameters via secure Bright Data node pools...`,
      `[+] Injecting advanced targeted boolean filters to capture leaks...`,
      `[+] Querying public asset registries for root domain targets: ${localizedDomain}...`
    ]);

    const timeouts = [
      setTimeout(() => setFeedLogs(prev => [...prev, `[⚡] Bright Data SERP API: Scraped deep hazard listings.`]), 400),
      setTimeout(() => setFeedLogs(prev => [...prev, `[⚡] Bright Data Web Unlocker: Decrypted structural nodes.`]), 900),
      setTimeout(() => setFeedLogs(prev => [...prev, `[⚙️] OpenRouter AI Layer: Evaluating credential matrices...`]), 1400),
      setTimeout(() => setFeedLogs(prev => [...prev, `[⚙️] Assessment Engine: Re-compiling mathematical risk models...`]), 2000),
    ];

    try {
      const baseUrl = import.meta.env.VITE_API_URL || "http://localhost:3001";
      const response = await fetch(`${baseUrl}/analyze`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ company: localizedDomain }),
      });

      if (!response.ok) {
        const errorData = await response.json().catch(() => ({}));
        throw new Error(errorData.error || `Server responded with state flag ${response.status}`);
      }
      
      const parsedJSON: ThreatIntelPayload = await response.json();
      setIntelData(parsedJSON);
      setIsMonitored(localStorage.getItem(`monitor-${localizedDomain}`) === "enabled");
      setFeedLogs(prev => [...prev, `[✓] Attack surface footprint intelligence compiled completely.`]);
    } catch (error: any) {
      console.error("OSINT PIPELINE CORRUPTION EVENT:", error);
      let descriptiveErrorMessage = error.message || "Unknown transport layer fault.";
      if (error instanceof TypeError && error.message.includes("failed to fetch")) {
        descriptiveErrorMessage = "Endpoint Refused. Ensure server.js is running on port 3001.";
      }
      setFeedLogs(prev => [...prev, `[❌] Transport Error: ${descriptiveErrorMessage}`]);
    } finally {
      timeouts.forEach(clearTimeout);
      setLoading(false);
    }
  }

  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === "Enter") generateThreatBrief();
  };

  const getScoreColor = (score: number | undefined) => {
    if (score === null || score === undefined) return "text-zinc-500";
    if (score >= 7.5) return "text-red-500";
    if (score >= 5.0) return "text-orange-500";
    if (score >= 2.5) return "text-yellow-500";
    return "text-green-500";
  };

  const getProgressBarColor = (score: number | undefined) => {
    if (!score || score >= 7.5) return "bg-red-500";
    if (score >= 5.0) return "bg-orange-500";
    if (score >= 2.5) return "bg-yellow-500";
    return "bg-green-500";
  };

  // Helper mapping colors cleanly to standard SOC signal classifications
  const getBadgeColor = (type: string | undefined) => {
    if (!type) return "bg-zinc-900 text-zinc-400 border-zinc-800";
    const norm = type.toUpperCase();
    if (norm.includes("INCIDENT")) return "bg-red-950 text-red-400 border-red-900/40";
    if (norm.includes("DISCLOSURE")) return "bg-blue-950 text-blue-400 border-blue-900/40";
    if (norm.includes("IMPERSONATION") || norm.includes("CAMPAIGN")) return "bg-orange-950 text-orange-400 border-orange-900/40";
    return "bg-zinc-900 text-zinc-300 border-zinc-800";
  };

  return (
    <div className="min-h-screen bg-black text-green-400 p-6 font-mono selection:bg-green-500 selection:text-black">
      
      {/* PANEL TITLE SYSTEM HEADER */}
      <div className="mb-8 border-b border-green-900/60 pb-4 flex flex-col md:flex-row justify-between items-start md:items-end gap-2">
        <div>
          <h1 className="text-3xl font-black tracking-tighter text-green-400 uppercase">
            AI Red Team Investigator
          </h1>
          <p className="text-zinc-400 text-xs mt-1">
            Ethical Attack Surface Vector Mapping & Audit Log Generation via Bright Data Infrastructure.
          </p>
        </div>
        <div className="text-right text-xs text-zinc-500 font-bold uppercase tracking-widest">
          Track 3: Security & Compliance Submission
        </div>
      </div>

      {/* INPUT CONTROL BAR CONTAINER */}
      <div className="flex flex-col sm:flex-row gap-4 mb-6">
        <input
          type="text"
          placeholder="ENTER TARGET ROOT DOMAIN ONLY (e.g., okta.com, lastpass.com)..."
          value={domain}
          onChange={(e) => setDomain(e.target.value)}
          onKeyDown={handleKeyDown}
          disabled={loading}
          className="flex-1 p-4 rounded bg-zinc-950 border border-green-500/20 outline-none focus:border-green-400 font-bold tracking-wider text-white disabled:opacity-50 text-sm transition-all placeholder:text-zinc-700"
        />
        <div className="flex gap-2">
          <button
            onClick={generateThreatBrief}
            disabled={loading || !domain.trim()}
            className="flex-1 sm:flex-none bg-green-500 text-black px-8 py-4 rounded font-black uppercase tracking-wider text-sm hover:bg-green-400 disabled:bg-zinc-900 disabled:text-zinc-600 transition whitespace-nowrap"
          >
            {loading ? "Parsing Domain..." : "Map Attack Surface"}
          </button>
          <button
            onClick={toggleContinuousMonitoring}
            disabled={!domain.trim() || loading}
            className="bg-zinc-950 border border-zinc-800 text-zinc-400 px-6 py-4 rounded font-bold uppercase tracking-wider text-sm hover:border-zinc-700 hover:text-white disabled:opacity-40 transition whitespace-nowrap"
          >
            Monitor Domain
          </button>
        </div>
      </div>

      <div className="grid grid-cols-12 gap-6">
        
        {/* LEFT MAIN INFORMATION CONTROL MATRIX COLUMN */}
        <div className="col-span-12 lg:col-span-5 space-y-6">
          
          {/* EXPLAINABLE RISK DASHBOARD */}
          <div className="border border-green-500/30 bg-zinc-950 p-4 rounded shadow-lg">
            <h3 className="text-xs font-bold text-zinc-400 uppercase tracking-widest mb-3 border-b border-zinc-900 pb-2">
              // Threat Assessment Index
            </h3>
            <div className="flex items-center justify-between mb-4">
              <div className={`text-6xl font-black ${getScoreColor(intelData?.risk_analysis?.score)}`}>
                {intelData?.risk_analysis?.score !== undefined ? intelData.risk_analysis.score.toFixed(1) : "0.0"}
                <span className="text-xs text-zinc-600 font-normal">/10</span>
              </div>
              <div className="text-right">
                <span className="text-xs text-zinc-500 block font-bold">EXPOSURE VECTOR:</span>
                <span className={`text-xs font-black uppercase tracking-widest bg-zinc-900 px-2 py-1 rounded border border-zinc-800 ${getScoreColor(intelData?.risk_analysis?.score)}`}>
                  {intelData?.risk_analysis?.score ? (
                    intelData.risk_analysis.score >= 7.5 ? "CRITICAL EXPOSURE" : 
                    intelData.risk_analysis.score >= 5.0 ? "HIGH PROFILE" : 
                    intelData.risk_analysis.score >= 2.5 ? "MEDIUM PROFILE" : "MINIMAL RECON FOOTPRINT"
                  ) : "UNKNOWN"}
                </span>
              </div>
            </div>

            {/* FIXED SYSTEM METRIC PROGRESSION BARS BLOCK */}
            <h4 className="text-[10px] font-black text-zinc-500 uppercase tracking-widest mb-3 px-1">// Enterprise Vector Hazard Profiles</h4>
            <div className="space-y-3 mb-4 bg-zinc-900/20 p-3 rounded border border-zinc-900/80">
              <div>
                <div className="flex justify-between text-xs mb-1 text-zinc-400">
                  <span>Credential Risk Profile</span>
                  <span className="font-bold text-white">{intelData?.risk_analysis?.breakdown?.credential_risk?.toFixed(1) || "0.0"}</span>
                </div>
                <div className="w-full bg-zinc-900 h-1.5 rounded-full overflow-hidden">
                  <div className={`h-full transition-all duration-500 ${getProgressBarColor(intelData?.risk_analysis?.score)}`} style={{ width: `${Math.min((intelData?.risk_analysis?.breakdown?.credential_risk || 0) * 40, 100)}%` }}></div>
                </div>
              </div>
              <div>
                <div className="flex justify-between text-xs mb-1 text-zinc-400">
                  <span>Infrastructure Vulnerabilities</span>
                  <span className="font-bold text-white">{intelData?.risk_analysis?.breakdown?.infrastructure_risk?.toFixed(1) || "0.0"}</span>
                </div>
                <div className="w-full bg-zinc-900 h-1.5 rounded-full overflow-hidden">
                  <div className={`h-full transition-all duration-500 ${getProgressBarColor(intelData?.risk_analysis?.score)}`} style={{ width: `${Math.min((intelData?.risk_analysis?.breakdown?.infrastructure_risk || 0) * 40, 100)}%` }}></div>
                </div>
              </div>
              <div>
                <div className="flex justify-between text-xs mb-1 text-zinc-400">
                  <span>Application Layer Attack Surface</span>
                  <span className="font-bold text-white">{intelData?.risk_analysis?.breakdown?.application_risk?.toFixed(1) || "0.0"}</span>
                </div>
                <div className="w-full bg-zinc-900 h-1.5 rounded-full overflow-hidden">
                  <div className={`h-full transition-all duration-500 ${getProgressBarColor(intelData?.risk_analysis?.score)}`} style={{ width: `${Math.min((intelData?.risk_analysis?.breakdown?.application_risk || 0) * 40, 100)}%` }}></div>
                </div>
              </div>
              <div>
                <div className="flex justify-between text-xs mb-1 text-zinc-400">
                  <span>Brand Exposure / Spoofing Risks</span>
                  <span className="font-bold text-white">{intelData?.risk_analysis?.breakdown?.brand_risk?.toFixed(1) || "0.0"}</span>
                </div>
                <div className="w-full bg-zinc-900 h-1.5 rounded-full overflow-hidden">
                  <div className={`h-full transition-all duration-500 ${getProgressBarColor(intelData?.risk_analysis?.score)}`} style={{ width: `${Math.min((intelData?.risk_analysis?.breakdown?.brand_risk || 0) * 40, 100)}%` }}></div>
                </div>
              </div>
            </div>

            {intelData?.risk_analysis?.factors && (
              <div className="pt-3 border-t border-zinc-900 space-y-1.5 text-xs text-zinc-400 leading-relaxed">
                {intelData.risk_analysis.factors.map((factor, idx) => (
                  <div key={idx} className="flex gap-2 items-start bg-zinc-900/20 p-1.5 rounded border border-zinc-900">
                    <span className="text-green-500 select-none">▪</span>
                    <span>{factor.text}</span>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* ACTIVE PERSISTENT BACKGROUND MONITOR STATUS CARD */}
          {isMonitored && (
            <div className="border border-green-500/40 bg-zinc-950 p-4 rounded shadow-lg">
              <h3 className="text-xs font-bold text-green-400 uppercase tracking-widest mb-2 flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-green-500 animate-ping"></span>
                Continuous Domain Monitor Active
              </h3>
              <div className="text-xs text-zinc-400 space-y-1 bg-green-950/20 p-3 rounded border border-green-900/40">
                <div className="flex justify-between"><span className="text-zinc-500">Monitoring Status:</span> <span className="text-green-400 font-bold">✓ Enabled</span></div>
                <div className="flex justify-between"><span className="text-zinc-500">Engine Frequency:</span> <span className="text-white">Real-Time Sync</span></div>
                <div className="flex justify-between"><span className="text-zinc-500">Next Deep Analysis:</span> <span className="text-yellow-500 font-bold">24 Hours</span></div>
              </div>
            </div>
          )}

          {/* INTEGRATED TRANSPARENT BRIGHT DATA TRACK LAYER ENGINE PANEL */}
          <div className="border border-zinc-800 bg-zinc-950 p-4 rounded shadow-lg">
            <h3 className="text-xs font-bold text-zinc-400 uppercase tracking-widest mb-3 border-b border-zinc-900 pb-2">
              // Active Data Infrastructure Channels
            </h3>
            <div className="grid grid-cols-2 gap-2 text-[11px]">
              <div className="bg-zinc-900/60 p-2 rounded border border-zinc-900 flex items-center gap-1.5 text-zinc-300">
                <span className="text-green-400">✓</span> Bright Data SERP API
              </div>
              <div className="bg-zinc-900/60 p-2 rounded border border-zinc-900 flex items-center gap-1.5 text-zinc-300">
                <span className="text-green-400">✓</span> Bright Data Web Unlocker
              </div>
              <div className="bg-zinc-900/60 p-2 rounded border border-zinc-900 flex items-center gap-1.5 text-zinc-300">
                <span className="text-green-400">✓</span> OpenRouter AI Hub
              </div>
              <div className="bg-zinc-900/60 p-2 rounded border border-zinc-900 flex items-center gap-1.5 text-zinc-300">
                <span className="text-green-400">✓</span> Threat Risk Engine
              </div>
            </div>
          </div>

          {/* CONSOLE FEED LOGGER */}
          <div className="border border-zinc-900 bg-zinc-950 p-4 rounded h-[140px] flex flex-col justify-between shadow-lg">
            <div>
              <h3 className="text-xs font-bold text-zinc-500 uppercase tracking-widest mb-2 border-b border-zinc-900 pb-2">
                // System Operations Monitor
              </h3>
              <div className="space-y-1 text-[11px] leading-relaxed max-h-[90px] overflow-y-auto text-zinc-500">
                {feedLogs.map((log, i) => (
                  <p key={i} className={log.includes('✓') ? 'text-green-400' : log.includes('⚡') ? 'text-yellow-500' : log.includes('❌') ? 'text-red-500' : 'text-zinc-600'}>
                    {log}
                  </p>
                ))}
                {loading && <span className="inline-block w-2 h-3 bg-green-400 animate-pulse ml-1" />}
              </div>
            </div>
          </div>
        </div>

        {/* RIGHT ANALYTICAL EVIDENCE DISCOVERY DOSSIER COLUMN */}
        <div className="col-span-12 lg:col-span-7 space-y-6">
          
          {/* DOSSIER SUMMARY HEADLINE BLOCK */}
          <div className="border border-green-500/30 bg-zinc-950 p-6 rounded shadow-lg">
            <h2 className="text-xs font-bold text-zinc-500 uppercase tracking-widest mb-3 border-b border-zinc-900 pb-2">
              // ACTIVE RISK INTEL RECORD
            </h2>
            {intelData ? (
              <>
                <h1 className="text-xl font-black text-white tracking-tight mb-2 uppercase">
                  {intelData.headline}
                </h1>
                <p className="text-zinc-400 text-xs leading-relaxed border-l border-green-500 pl-3 py-0.5 mb-4">
                  {intelData.executive_brief}
                </p>

                {/* AI ANALYST VERDICT PANEL PRESENTATION */}
                <div className="mt-4 border border-zinc-900 bg-zinc-900/20 rounded p-3">
                  <div className="text-[10px] text-zinc-500 uppercase font-bold tracking-wider">
                    AI Threat Analyst Verdict
                  </div>
                  <div className="mt-2 text-xs grid grid-cols-1 sm:grid-cols-3 gap-2 text-zinc-400">
                    <div>
                      Current Risk Level:
                      <span className={`ml-2 font-bold ${getScoreColor(intelData.risk_analysis.score)}`}>
                        {intelData.risk_analysis.score >= 7.5 ? "CRITICAL" : intelData.risk_analysis.score >= 5.0 ? "HIGH" : intelData.risk_analysis.score >= 2.5 ? "MEDIUM" : "LOW"}
                      </span>
                    </div>
                    <div>
                      Primary Threat:
                      <span className="ml-2 text-white font-medium">
                        {intelData.primary_threat || "Credential Exposure"}
                      </span>
                    </div>
                    <div>
                      Data Confidence:
                      <span className="ml-2 text-green-400 font-medium">
                        {intelData.evidence_cards[0]?.confidence || 85}%
                      </span>
                    </div>
                  </div>
                </div>
              </>
            ) : (
              <p className="text-zinc-600 italic text-xs">System idle. Provide an operational domain identifier target above to execute automated reconnaissance workflows.</p>
            )}
          </div>

          {/* RECOMMENDED ACTION LAYER (DECISION SUPPORT ENGINE) */}
          {intelData?.recommendations && intelData.recommendations.length > 0 && (
            <div className="border border-red-500/20 bg-zinc-950 p-4 rounded shadow-md border-l-4 border-l-red-500">
              <h3 className="text-xs uppercase font-bold mb-3 tracking-widest text-zinc-200 flex items-center gap-1.5">
                <span>⚠</span> Recommended Action Layer (Decision Support)
              </h3>
              <div className="space-y-2 text-xs">
                {intelData.recommendations.map((r, idx) => (
                  <div key={idx} className="bg-zinc-900/60 p-2.5 rounded border border-zinc-900 flex gap-2 items-center">
                    <span className={`px-1.5 py-0.5 rounded text-[9px] font-black tracking-wider ${r.priority === "HIGH" ? "bg-red-950 text-red-400 border border-red-900/50" : "bg-zinc-900 text-zinc-400"}`}>
                      {r.priority}
                    </span>
                    <span className="text-zinc-200">{r.action}</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* CLASSIFIED EVIDENCE MATCH CARDS */}
          {intelData?.evidence_cards && (
            <div className="space-y-3">
              <h2 className="text-xs font-bold text-zinc-400 uppercase tracking-widest px-1">
                // Discovered High-Fidelity Signal Matches ({intelData.evidence_cards.length})
              </h2>
              <div className="space-y-3">
                {intelData.evidence_cards.map((card, idx) => (
                  <div key={idx} className="border border-zinc-900 bg-zinc-950 rounded overflow-hidden shadow-md">
                    <div className="bg-zinc-900/60 px-4 py-2 flex flex-col sm:flex-row sm:items-center justify-between gap-1 border-b border-zinc-900 text-xs">
                      <div className="text-zinc-200 font-bold truncate max-w-xs md:max-w-md">
                        Source: "{card.source_title}"
                      </div>
                      
                      {/* NEW HIGHLIGHT: DYNAMICALLY TYPED SIGNAL TAXONOMY BADGE VALUE */}
                      <div className={`px-2 py-0.5 rounded border text-[9px] font-black tracking-widest text-center self-start sm:self-center uppercase ${getBadgeColor(card.signal_type)}`}>
                        {card.signal_type || "EXTERNAL EXPOSURE"}
                      </div>
                    </div>
                    
                    <div className="p-4 text-xs space-y-3">
                      <div className="flex justify-between items-center text-[10px] text-zinc-500 border-b border-zinc-900/40 pb-1.5">
                        <span>CARD REF: EVID-0{idx + 1}</span>
                        <span>DATA FIDELITY CONFIDENCE: <span className="text-green-400 font-bold">{card.confidence || 75}%</span></span>
                      </div>
                      
                      <div>
                        <span className="text-zinc-500 block font-bold uppercase text-[9px] mb-0.5">Scraped Footprint Finding:</span>
                        <p className="text-zinc-300 bg-zinc-900/30 p-2 rounded border border-zinc-300/10 leading-relaxed">{card.finding}</p>
                      </div>
                      <div>
                        <span className="text-zinc-500 block font-bold uppercase text-[9px] mb-0.5">Risk Exposure Vector Impact:</span>
                        <p className="text-orange-400/90 leading-relaxed">{card.risk_impact || "Public reference exposure allows open-source infrastructure intelligence assembly."}</p>
                      </div>
                      
                      {card.url && card.url !== "#" && (
                        <div className="pt-2 border-t border-zinc-900 text-right">
                          <a 
                            href={card.url} 
                            target="_blank" 
                            rel="noreferrer" 
                            className="inline-block bg-zinc-900 hover:bg-zinc-850 text-blue-400 border border-zinc-800 px-3 py-1.5 rounded font-bold transition text-[10px]"
                          >
                            Verify Live Scraped Source Document ↗
                          </a>
                        </div>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* TACTICAL PATH NARRATIVE VECTOR */}
          {intelData?.attack_narrative && (
            <div className="border border-zinc-900 bg-zinc-950 p-6 rounded shadow-lg">
              <h2 className="text-xs font-bold text-zinc-400 uppercase tracking-widest mb-4 border-b border-zinc-900 pb-2">
                // Tactical Kill-Chain Projection
              </h2>
              <div className="relative border-l border-zinc-800 ml-3 space-y-4 my-1">
                {intelData.attack_narrative.map((node, index) => (
                  <div key={index} className="relative pl-6">
                    <div className="absolute -left-[5px] top-1 w-2 h-2 rounded-full bg-green-500"></div>
                    <span className="text-[10px] text-zinc-500 uppercase tracking-widest block font-black">
                      PHASE {node.step || index + 1}: {node.phase}
                    </span>
                    <p className="text-xs text-zinc-300 mt-1 leading-relaxed">
                      {node.description}
                    </p>
                  </div>
                ))}
              </div>
            </div>
          )}

        </div>

      </div>
    </div>
  );
}